# Nexora BD Android App — Premium Edition

## Project setup
This project wraps the existing WordPress/WooCommerce storefront in an Android WebView and adds a premium home screen with service shortcuts.

## Buttons
- E-Commerce: http://nexorabd.free.nf
- Mobile Recharge: https://durbar.onlineflexiload.com/login
- Calling Card: http://49.12.84.49/nasrintel/
- WhatsApp Support: https://wa.me/9647515391250

## Chromebook / GitHub Actions APK build
1. Download and extract this ZIP.
2. Open `https://github.com/nexorabdonline-spec/nexora-bd-android`.
3. Upload the extracted project files/folders into the repository root. Do not upload the ZIP as the only file. Make sure `.github/workflows/build-apk.yml` is included.
4. Commit the changes to the `main` branch.
5. Open the repository's Actions tab and choose `Build Nexora BD APK`. It also runs automatically after a push to `main`.
6. Open the latest run. Wait for the green success check.
7. Under Artifacts, download `Nexora-BD-debug-APK`, unzip it, and install `app-debug.apk` on your Android phone.

## WooCommerce integration notes
The E-Commerce shortcut opens the current WordPress/WooCommerce website, so products, cart and checkout depend on what is already configured on the website. This is a WebView wrapper, not a custom WooCommerce REST API integration. For safer logins and checkout, use the HTTPS version of your store if its SSL certificate is working.

## Important limitations
- Login/Register in this starter are demo screens only; they do not create or store real accounts.
- Recharge and calling-card shortcuts open the provider websites. Transactions remain controlled by those providers.
- WhatsApp opens the support link. The link currently uses the number previously supplied: +9647515391250. Change it in `index.html` if you want a different number.
- The project ZIP is source code, not a compiled APK. GitHub Actions must complete successfully to produce the APK.
