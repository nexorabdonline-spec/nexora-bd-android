package com.nexorabd.app;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setStatusBarColor(Color.rgb(202,255,0));
  getWindow().setNavigationBarColor(Color.rgb(6,43,128));
  WebView web = new WebView(this);
  web.setBackgroundColor(Color.rgb(244,247,251));
  WebSettings settings = web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  web.setWebViewClient(new WebViewClient() {
   @Override
   public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
    String url = request.getUrl().toString();
    if (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/") || url.startsWith("whatsapp://")) {
     try {
      Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
      startActivity(intent);
     } catch (Exception e) {
      view.loadUrl("https://wa.me/9647515391250");
     }
     return true;
    }
    return false;
   }
   @SuppressWarnings("deprecation")
   @Override
   public boolean shouldOverrideUrlLoading(WebView view, String url) {
    if (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/") || url.startsWith("whatsapp://")) {
     try {
      startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
     } catch (Exception e) {
      view.loadUrl("https://wa.me/9647515391250");
     }
     return true;
    }
    return false;
   }
  });
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
}
